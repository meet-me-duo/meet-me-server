package com.meetme.server.coordination.adapter.input.web

import com.meetme.server.config.ManagedAiRuntimeSelection
import com.meetme.server.config.OpenAiProperties
import com.meetme.server.coordination.adapter.output.integration.OpenAiLunaNaturalLanguageParserAdapter
import com.meetme.server.coordination.application.port.output.AnalysisInvocationRepository
import com.meetme.server.coordination.application.port.output.CoordinationAttemptRepository
import com.meetme.server.coordination.application.port.output.CoordinationRunRepository
import com.meetme.server.coordination.application.port.output.JitterPort
import com.meetme.server.coordination.application.port.output.MonotonicTimePort
import com.meetme.server.coordination.application.port.output.NaturalLanguageParserException
import com.meetme.server.coordination.application.port.output.NaturalLanguageParserPort
import com.meetme.server.coordination.application.port.output.ParserFailureKind
import com.meetme.server.coordination.application.port.output.RetryDelayPort
import com.meetme.server.coordination.application.service.GeminiBatchProcessor
import com.meetme.server.coordination.application.service.GeminiProcessingPersistenceService
import com.meetme.server.coordination.domain.CoordinationStatus
import com.meetme.server.precheck.adapter.output.provider.PrecheckProviderHttpTransport
import com.meetme.server.precheck.application.port.output.PrecheckRepository
import com.meetme.server.precheck.application.service.PreSubmissionCheckWorker
import com.meetme.server.shared.adapter.output.aihttp.AiHttpDispatchGate
import com.meetme.server.shared.application.port.output.AiDispatchModePort
import com.meetme.server.shared.application.port.output.AiTestOperationCampaignPort
import com.meetme.server.shared.application.port.output.DurableAiBudgetPort
import com.meetme.server.shared.application.port.output.IdGenerator
import com.meetme.server.shared.application.port.output.NewRoomAiBudgetPort
import com.meetme.server.shared.domain.CoordinationRunId
import com.meetme.server.submission.application.port.output.StructuredSubmissionRepository
import com.meetme.server.submission.application.port.output.SubmissionRepository
import jakarta.servlet.http.Cookie
import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.context.annotation.Primary
import org.springframework.http.MediaType
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status
import org.springframework.transaction.support.TransactionTemplate
import org.testcontainers.postgresql.PostgreSQLContainer
import java.math.BigInteger
import java.net.URI
import java.nio.file.Files
import java.security.MessageDigest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import kotlin.test.assertEquals
import kotlin.test.assertFails
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/** #144 managed configuration, INSERT receipt, PG/fence/gate, worker and final Luna; sockets use loopback TLS. */
@Import(DurableAnalysisInvocationPostgresTest.ControlledTime::class, Issue144ManagedTestOperationPostgresTest.Transport::class)
class Issue144ManagedTestOperationPostgresTest : CorrectionRoundPostgresFixture() {
    @Autowired private lateinit var worker: PreSubmissionCheckWorker

    @Autowired private lateinit var budgets: DurableAiBudgetPort

    @Autowired private lateinit var bootstrap: NewRoomAiBudgetPort

    @Autowired private lateinit var selection: ManagedAiRuntimeSelection

    @Autowired private lateinit var campaigns: AiTestOperationCampaignPort

    @Autowired private lateinit var gate: AiHttpDispatchGate

    @Autowired private lateinit var clock: Clock

    @Autowired private lateinit var time: DurableAnalysisInvocationPostgresTest.DurableClock

    @Autowired private lateinit var runs: CoordinationRunRepository

    @Autowired private lateinit var submissions: SubmissionRepository

    @Autowired private lateinit var structured: StructuredSubmissionRepository

    @Autowired private lateinit var attempts: CoordinationAttemptRepository

    @Autowired private lateinit var invocations: AnalysisInvocationRepository

    @Autowired private lateinit var persistence: GeminiProcessingPersistenceService

    @Autowired private lateinit var prechecks: PrecheckRepository

    @BeforeEach
    fun resetSyntheticTimeAndNetwork() {
        time.now = NOW
        proxy.clear()
    }

    @Test
    fun `TO30 actual create initializes the new test room without promoting an existing unconfigured ledger`() {
        val old = UUID.randomUUID()
        jdbc.update(
            """
            INSERT INTO meeting_rooms(id,invite_code,purpose,meeting_mode,time_zone_id,search_start_date,
                search_end_date,search_range_source,manual_only,collection_status,created_at,version)
            VALUES (?,?,'old synthetic','REMOTE','Asia/Seoul','2026-10-07','2026-10-12',
                'HOST_SPECIFIED',true,'COLLECTING',?,0)
            """.trimIndent(),
            old,
            old.toString().replace("-", "").take(22),
            NOW.atOffset(ZoneOffset.UTC),
        )
        val before = jdbc.queryForMap("SELECT * FROM ai_room_budgets WHERE room_id=?", old)
        assertFails { TransactionTemplate(transactionManager).executeWithoutResult { bootstrap.initialize(old, NOW) } }
        assertEquals(before, jdbc.queryForMap("SELECT * FROM ai_room_budgets WHERE room_id=?", old))
        val created = create()
        val budget = assertNotNull(budgets.snapshot(created.id))
        assertEquals("READY", budget.state.name)
        assertNotNull(budget.epochId)
        assertEquals("TEST_PHYSICAL_REQUEST", assertNotNull(budget.unit).code)
        assertEquals(0, assertNotNull(budget.unit).scale)
        assertEquals(BigInteger.valueOf(31), budget.cap)
        assertEquals(0, budget.testFinalSlots)
        assertEquals(BigInteger.ZERO, budget.held)
        assertEquals(0, proxy.connections.get())
    }

    @Test
    fun `TO30 future and expired campaigns deny actual room creation without leaving an inserted room`() {
        val campaign = assertNotNull(assertNotNull(selection.policy).testOperation)
        val host = accounts.newAccount("synthetic-outside-campaign-host")
        val before = jdbc.queryForObject("SELECT count(*) FROM meeting_rooms", Int::class.java)
        for (instant in listOf(campaign.startsAt.minusNanos(1), campaign.expiresAt)) {
            time.now = instant
            mvc
                .perform(
                    post("/api/rooms")
                        .cookie(host)
                        .header("Origin", ORIGIN)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(CREATE_ROOM),
                ).andExpect(status().isInternalServerError)
            assertEquals(before, jdbc.queryForObject("SELECT count(*) FROM meeting_rooms", Int::class.java))
        }
        assertEquals(0, proxy.connections.get())
    }

    @Test
    fun `TO31 real personal and final dispatch share one test campaign without any monetary input or paid network`() {
        val created = create()
        val member = accounts.newAccount("synthetic-test-operation-member")
        mvc
            .perform(
                post("/api/rooms/{code}/participants", created.code)
                    .cookie(member)
                    .header("Origin", ORIGIN)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{}"),
            ).andExpect(status().isCreated)
        for ((owner, text) in listOf(created.host to "first synthetic test input", member to "second synthetic test input")) {
            proxy.enqueue(DECISION)
            proxy.enqueue(GENERATION)
            submit(created.code, owner, text)
            assertTrue(assertDoesNotThrow { worker.runOne() })
            val current =
                mvc
                    .perform(get("/api/rooms/{code}/submission/checks/current", created.code).cookie(owner))
                    .andExpect(status().isOk)
                    .andReturn()
                    .response.contentAsString
            assertEquals(
                "CLEAR",
                mapper
                    .readTree(current)
                    .path("check")
                    .path("status")
                    .asText(),
            )
            assertTrue(mapper.readTree(current).path("submission_complete").asBoolean())
        }
        assertEquals(4, proxy.requests.size)
        val beforeFinal = assertNotNull(budgets.snapshot(created.id))
        assertEquals(BigInteger.valueOf(4), beforeFinal.held)
        assertEquals(5, beforeFinal.testFinalSlots)
        val active = assertNotNull(jdbc.queryForObject("SELECT active_run_id FROM meeting_rooms WHERE id=?", UUID::class.java, created.id))
        val run = assertNotNull(runs.findById(CoordinationRunId(active)))
        val payload =
            mapper.writeValueAsString(
                mapOf(
                    "schema_version" to "3",
                    "results" to
                        run.batch.submissionVersionIds.map {
                            mapOf(
                                "input_ref" to it.value.toString(),
                                "rejection_code" to null,
                                "conditions" to
                                    listOf(
                                        mapOf(
                                            "type" to "TIME_WINDOW",
                                            "polarity" to "AVAILABLE",
                                            "date" to "2026-10-07",
                                            "day_of_week" to null,
                                            "start_time" to "19:00",
                                            "end_time" to "21:00",
                                        ),
                                    ),
                            )
                        },
                ),
            )
        proxy.enqueue(
            mapper.writeValueAsString(
                mapOf(
                    "status" to "completed",
                    "output" to
                        listOf(
                            mapOf(
                                "type" to "message",
                                "content" to listOf(mapOf("type" to "output_text", "text" to payload)),
                            ),
                        ),
                    "usage" to
                        mapOf(
                            "input_tokens" to 256,
                            "output_tokens" to 32,
                            "output_tokens_details" to mapOf("reasoning_tokens" to 20),
                        ),
                ),
            ),
        )
        val fallback =
            OpenAiLunaNaturalLanguageParserAdapter(
                OpenAiProperties(apiKey = "synthetic-not-real"),
                mapper,
                proxy.client(),
                URI("https://api.openai.com/v1/responses"),
                dispatchGate = gate,
            )
        val noNetworkPrimary = NaturalLanguageParserPort { throw NaturalLanguageParserException(ParserFailureKind.NETWORK) }
        GeminiBatchProcessor(
            runs,
            submissions,
            structured,
            attempts,
            noNetworkPrimary,
            IdGenerator { UUID.randomUUID() },
            RetryDelayPort {},
            JitterPort { 0 },
            MonotonicTimePort { System.nanoTime() },
            clock,
            persistence,
            fallbackParser = fallback,
            invocationRepository = invocations,
            prechecks = prechecks,
            dispatchMode = AiDispatchModePort { true },
        ).process(run.batch.id)
        assertEquals(5, proxy.requests.size)
        assertEquals(
            listOf("api.typesafe.ai", "api.openai.com", "api.typesafe.ai", "api.openai.com", "api.openai.com"),
            proxy.requests.map { it.host },
        )
        assertTrue(proxy.failures.isEmpty())
        val complete = assertNotNull(budgets.snapshot(created.id))
        assertEquals(beforeFinal.epochId, complete.epochId)
        assertEquals(BigInteger.valueOf(5), complete.held)
        assertEquals(BigInteger.ZERO, complete.settled)
        assertEquals(4, complete.testFinalSlots)
        assertEquals(CoordinationStatus.MATCHING, assertNotNull(runs.findById(run.id)).status)
        val campaign = assertNotNull(assertNotNull(selection.policy).testOperation)
        assertTrue(
            TransactionTemplate(transactionManager).execute { campaigns.reserve(campaign, 21, NOW.plusSeconds(60)) } == true,
            "Four personal requests plus one 5-slot final reserve consume nine conservative campaign slots",
        )
        assertTrue(TransactionTemplate(transactionManager).execute { !campaigns.reserve(campaign, 1, NOW.plusSeconds(60)) } == true)
    }

    private fun create(): Created {
        val host = accounts.newAccount("synthetic-test-operation-host")
        val response =
            mvc
                .perform(
                    post("/api/rooms")
                        .cookie(host)
                        .header("Origin", ORIGIN)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(CREATE_ROOM),
                ).andExpect(status().isCreated)
                .andReturn()
                .response
        val code = document(response).getValue("invite_code").toString()
        val id = assertNotNull(jdbc.queryForObject("SELECT id FROM meeting_rooms WHERE invite_code=?", UUID::class.java, code))
        return Created(id, code, host)
    }

    private fun submit(
        code: String,
        owner: Cookie,
        text: String,
    ) {
        mvc
            .perform(
                post("/api/rooms/{code}/submission/checks", code)
                    .cookie(owner)
                    .header("Origin", ORIGIN)
                    .header("Accept-Language", "ko-KR")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(
                        mapper.writeValueAsString(mapOf("request_id" to UUID.randomUUID(), "expected_revision" to 0, "raw_text" to text)),
                    ),
            ).andExpect(status().isAccepted)
    }

    private data class Created(
        val id: UUID,
        val code: String,
        val host: Cookie,
    )

    @TestConfiguration
    class Transport {
        @Bean @Primary
        fun loopbackOnlyPrecheckTransport() = PrecheckProviderHttpTransport(proxy.client())
    }

    companion object {
        private val NOW = Instant.parse("2026-10-07T00:00:00Z")
        private val directory = Files.createTempDirectory("issue144-synthetic-campaign-")
        private val proxy = Issue131CanonicalTlsProxy(directory)
        private const val CREATE_ROOM =
            """{"purpose":"synthetic nonmoney test","meeting_mode":"REMOTE","host_display_name":"host",""" +
                """"manual_only":false,"expected_participants":2,"search_start_date":"2026-10-07","search_end_date":"2026-10-12"}"""
        private val json =
            """{"protocol":"meetme-managed-ai-policy-v1","state":"TEST_OPERATION",""" +
                """"campaignId":"14414414-4144-4144-8144-144144144144","startsAt":"2026-10-06T23:59:00Z",""" +
                """"expiresAt":"2026-10-07T01:00:00Z","maximumRequests":30,"minimumConfidence":0.73}"""
        private val policy = Files.writeString(directory.resolve("test-operation.json"), json)
        private val postgres = PostgreSQLContainer("postgres:18-alpine").apply { start() }
        private const val DECISION =
            """{"model":"jev-1.14.0","answers":{"material_ambiguity":{"type":"choice",""" +
                """"choice":"NEEDS_REVIEW","confidence":0.85,"probabilities":{"CLEAR":0.05,"NEEDS_REVIEW":0.9,"INDETERMINATE":0.05}}},""" +
                """"usage":{"input_tokens":100,"output_tokens":0}}"""
        private const val GENERATION =
            """{"status":"completed","output":[{"type":"message","content":[{"type":"output_text",""" +
                """"text":"{\"verdict\":\"CLEAR\",\"prompt\":null,\"sourceExcerpt\":null,\"choices\":null}"}]}],""" +
                """"usage":{"input_tokens":256,"output_tokens":32,"output_tokens_details":{"reasoning_tokens":20}}}"""

        @JvmStatic @DynamicPropertySource
        fun properties(registry: DynamicPropertyRegistry) {
            registerCorrectionDatabase(registry, postgres)
            for (name in listOf(
                "meetme.precheck.provider.enabled",
                "meetme.precheck.decision-routing.enabled",
                "meetme.precheck.classifier.enabled",
                "meetme.ai.budget.enabled",
            )) {
                registry.add(name) { true }
            }
            registry.add("meetme.precheck.classifier.minimum-confidence") { 0.73 }
            registry.add("meetme.ai.budget.policy-path") { policy.toString() }
            registry.add("meetme.ai.budget.policy-sha256") {
                MessageDigest.getInstance("SHA-256").digest(json.toByteArray()).joinToString("") { "%02x".format(it) }
            }
            for (name in listOf("meetme.gemini.api-key", "meetme.openai.api-key", "meetme.typesafe.api-key")) {
                registry.add(name) { "synthetic-not-a-real-key" }
            }
        }

        @JvmStatic @AfterAll
        fun stopSyntheticFixture() {
            proxy.close()
            postgres.stop()
        }
    }
}
