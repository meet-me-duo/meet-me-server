package com.meetme.server.shared.adapter.output.budget

import com.meetme.server.config.AiRuntimePolicyProperties
import com.meetme.server.config.ApprovedAiRuntimePolicy
import com.meetme.server.config.ManagedAiRuntimeConfiguration
import com.meetme.server.config.ManagedAiRuntimePolicyLoader
import com.meetme.server.config.ManagedAiRuntimeSelection
import com.meetme.server.shared.application.port.output.AiBudgetAuthorityRegistryPort
import com.meetme.server.shared.application.port.output.AiBudgetBillRequest
import com.meetme.server.shared.application.port.output.AiBudgetExecution
import com.meetme.server.shared.application.port.output.AiBudgetExecutionKind
import com.meetme.server.shared.application.port.output.AiBudgetQuoteRequest
import com.meetme.server.shared.application.port.output.AiBudgetUnit
import com.meetme.server.shared.application.port.output.AiPhysicalCallSpec
import com.meetme.server.shared.application.port.output.AiPhysicalOperation
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.api.io.TempDir
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.EnumSource
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import java.math.BigInteger
import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import java.util.UUID
import java.util.function.Supplier
import kotlin.test.assertEquals
import kotlin.test.assertFails
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** #144 nonmonetary admission only. Values are synthetic and never activate an operating runtime. */
class Issue144TestOperationPolicyTest {
    @TempDir lateinit var directory: Path

    private val now = Instant.parse("2026-10-18T00:00:00Z")
    private val clock = Clock.fixed(now, ZoneOffset.UTC)
    private val campaignId = UUID.fromString("11111111-2222-4333-8444-555555555555")
    private val starts = now.minusSeconds(60)
    private val expires = now.plusSeconds(120)

    @Test
    fun `TO01 exact test artifact supplies request units and no monetary policy inputs`() {
        val file = file(json())
        val policy = assertNotNull(assertDoesNotThrow { load(file) })
        assertEquals(AiBudgetUnit("TEST_PHYSICAL_REQUEST", 0), policy.unit)
        assertEquals(BigInteger.valueOf(21), policy.roomCap, "N+1 preserves the existing strict exposure less-than cap rule")
        assertEquals(0.73, policy.minimumConfidence)
        assertEquals(Issue144PhysicalProfiles.values.keys, policy.operations.keys)
        val campaign = assertNotNull(policy.testOperation)
        assertEquals(campaignId, campaign.id)
        assertEquals(hash(Files.readString(file)), campaign.policyFingerprint)
        assertEquals(policy.fingerprint, campaign.policyFingerprint)
        assertEquals(20L, campaign.maximumRequests)
        assertEquals(starts, campaign.startsAt)
        assertEquals(expires, campaign.expiresAt)
        for ((operation, profile) in Issue144PhysicalProfiles.values) {
            val rule = policy.operations.getValue(operation)
            assertEquals(profile, rule.profileFingerprint)
            assertEquals(BigInteger.ONE, rule.maximumAmount)
            assertEquals(expires, rule.validUntil)
        }
    }

    @Test
    fun `TO02 syntactically valid future and expired campaigns can load but provide no current admission`() {
        for ((begin, end) in listOf(now.plusSeconds(1) to expires, starts to now, starts to now.minusSeconds(1))) {
            val policy = assertNotNull(assertDoesNotThrow { load(file(json(begin = begin, end = end))) })
            val authority = ConfiguredAiBudgetAuthorityRegistry(ManagedAiRuntimeSelection(true, policy), clock)
            assertNull(authority.quote(request(policy, AiPhysicalOperation.PRECHECK_CLASSIFICATION)))
            assertNull(authority.protectedFinalReserve(request(policy, AiPhysicalOperation.PRECHECK_CLASSIFICATION)))
        }
    }

    @Test
    fun `TO02 positive Long maximum is explicit and its strict room cap does not overflow Long`() {
        val policy = assertNotNull(assertDoesNotThrow { load(file(json(maximum = Long.MAX_VALUE.toString()))) })
        assertEquals(Long.MAX_VALUE, assertNotNull(policy.testOperation).maximumRequests)
        assertEquals(BigInteger.valueOf(Long.MAX_VALUE) + BigInteger.ONE, policy.roomCap)
    }

    @Test
    fun `TO02 partial malformed duplicate or monetary hybrid test configuration fails closed without echoing content`() {
        val valid = json()
        val mutations =
            listOf(
                valid.replace("\"maximumRequests\":20,", ""),
                valid.replace("\"minimumConfidence\":0.73", "\"minimumConfidence\":null"),
                valid.replace("\"minimumConfidence\":0.73", "\"minimumConfidence\":1.01"),
                valid.replace("\"minimumConfidence\":0.73", "\"minimumConfidence\":-0.01"),
                valid.replace("\"minimumConfidence\":0.73", "\"minimumConfidence\":1.00000000000000000001"),
                valid.replace("\"minimumConfidence\":0.73", "\"minimumConfidence\":-1e-999"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":0"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":-1"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":20.5"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":20.0"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":2e1"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":\"20\""),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":true"),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":9223372036854775808"),
                valid.replace(campaignId.toString(), "1-2-3-4-5"),
                valid.replace(campaignId.toString(), "11111111-2222-4333-8444-55555555555A"),
                valid.replace(starts.toString(), expires.toString()),
                valid.replace(starts.toString(), now.plusSeconds(121).toString()),
                valid.replace(starts.toString(), starts.toString().replace("Z", "+00:00")),
                valid.replace(starts.toString(), "2026-10-17T23:59:60Z"),
                valid.replace(starts.toString(), "2026-10-17T24:00:00Z"),
                valid.replace(starts.toString(), "0000-10-17T23:59:00Z"),
                valid.replace(starts.toString(), "2026-10-17T23:59:00.1234567890Z"),
                valid.replace("\"state\":\"TEST_OPERATION\",", "\"state\":\"TEST_OPERATION\",\"roomCap\":\"999\","),
                valid.replace("\"state\":\"TEST_OPERATION\",", "\"state\":\"TEST_OPERATION\",\"unit\":{},"),
                valid.replace("\"state\":\"TEST_OPERATION\",", "\"state\":\"TEST_OPERATION\",\"synthetic-sensitive\":\"must-not-leak\","),
                valid.replace("\"maximumRequests\":20", "\"maximumRequests\":20,\"maximumRequests\":40"),
            )
        for (changed in mutations) {
            val failure = assertFails { load(file(changed)) }
            val message = generateSequence(failure) { it.cause }.joinToString(" ") { it.message.orEmpty() }
            assertFalse(message.contains("must-not-leak"))
        }
    }

    @Test
    fun `TO03 test operation retains allOFF allON and exact threshold startup checks`() {
        val file = file(json())
        runner(file, 0).run { context ->
            assertNull(context.startupFailure)
            assertFalse(context.getBean(ManagedAiRuntimeSelection::class.java).enabled)
            assertNull(context.getBean(ManagedAiRuntimeSelection::class.java).policy)
        }
        for (mask in 1..14) runner(file, mask, "0.73").run { assertNotNull(it.startupFailure) }
        runner(file, 15).run { assertNotNull(it.startupFailure) }
        runner(file, 15, "0.74").run { assertNotNull(it.startupFailure) }
        runner(file, 15, "0.73").run { context ->
            assertNull(context.startupFailure)
            val selection = context.getBean(ManagedAiRuntimeSelection::class.java)
            assertTrue(selection.enabled)
            assertNotNull(assertNotNull(selection.policy).testOperation)
        }
    }

    @ParameterizedTest
    @EnumSource(AiPhysicalOperation::class)
    fun `TO04 fixed physical quotes bind the test campaign and consume exactly one nonmoney unit`(operation: AiPhysicalOperation) {
        val policy = assertNotNull(assertDoesNotThrow { load(file(json())) })
        val authority = ConfiguredAiBudgetAuthorityRegistry(ManagedAiRuntimeSelection(true, policy), clock)
        val original = request(policy, operation)
        val quote = assertNotNull(assertDoesNotThrow { authority.quote(original) })
        assertEquals(campaignId, quote.testCampaignId)
        assertEquals(BigInteger.ONE, quote.maximumAmount)
        assertEquals(AiBudgetUnit("TEST_PHYSICAL_REQUEST", 0), quote.unit)
        assertEquals(policy.fingerprint, quote.policyFingerprint)
        assertEquals(original.call.wholePayloadFingerprint, quote.wholePayloadFingerprint)
        assertEquals(original.call.profileFingerprint, quote.profileFingerprint)
        assertEquals(expires, quote.validUntil)
        assertEquals(policy.testOperation, authority.testOperationCampaign(policy.fingerprint))
        assertNull(authority.testOperationCampaign("f".repeat(64)))
        assertNull(authority.quote(original.copy(call = original.call.copy(profileFingerprint = "f".repeat(64)))))
        assertNull(authority.completeBill(AiBudgetBillRequest(UUID.randomUUID(), quote.quoteFingerprint, "usage-is-not-a-money-bill")))
        if (operation == AiPhysicalOperation.PRECHECK_CLASSIFICATION) {
            val protection = assertNotNull(authority.protectedFinalReserve(original))
            assertEquals(BigInteger.valueOf(5), protection.amount)
            assertEquals(quote.unit, protection.unit)
        }
    }

    @Test
    fun `TO03 missing and UNCONFIGURED defaults remain denying without a test campaign`() {
        assertNull(ManagedAiRuntimePolicyLoader.load(AiRuntimePolicyProperties(), clock))
        assertNull(load(file("""{"protocol":"meetme-managed-ai-policy-v1","state":"UNCONFIGURED"}""")))
        val denying: AiBudgetAuthorityRegistryPort = DenyAiBudgetAuthorityRegistry()
        assertNull(denying.testOperationCampaign("a".repeat(64)))
    }

    private fun runner(
        file: Path,
        mask: Int,
        threshold: String? = null,
    ): ApplicationContextRunner {
        val flags =
            listOf(
                "meetme.precheck.provider.enabled",
                "meetme.precheck.decision-routing.enabled",
                "meetme.precheck.classifier.enabled",
                "meetme.ai.budget.enabled",
            )
        val properties = flags.mapIndexed { index, key -> "$key=${mask and (1 shl index) != 0}" }.toMutableList()
        properties += "meetme.ai.budget.policy-path=$file"
        properties += "meetme.ai.budget.policy-sha256=${hash(Files.readString(file))}"
        if (threshold != null) properties += "meetme.precheck.classifier.minimum-confidence=$threshold"
        return ApplicationContextRunner()
            .withUserConfiguration(
                ManagedAiRuntimeConfiguration::class.java,
                AiBudgetAuthorityConfiguration::class.java,
            ).withBean(Clock::class.java, Supplier { clock })
            .withPropertyValues(*properties.toTypedArray())
    }

    private fun file(text: String): Path = Files.writeString(directory.resolve("synthetic-${UUID.randomUUID()}.json"), text)

    private fun load(file: Path): ApprovedAiRuntimePolicy? =
        ManagedAiRuntimePolicyLoader.load(
            AiRuntimePolicyProperties(file.toString(), hash(Files.readString(file))),
            clock,
        )

    private fun json(
        maximum: String = "20",
        begin: Instant = starts,
        end: Instant = expires,
    ): String =
        """{"protocol":"meetme-managed-ai-policy-v1","state":"TEST_OPERATION","campaignId":"$campaignId",""" +
            """"startsAt":"$begin","expiresAt":"$end","maximumRequests":$maximum,"minimumConfidence":0.73}"""

    private fun hash(text: String): String =
        MessageDigest
            .getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun request(
        policy: ApprovedAiRuntimePolicy,
        operation: AiPhysicalOperation,
    ): AiBudgetQuoteRequest =
        AiBudgetQuoteRequest(
            AiBudgetExecution(
                UUID.randomUUID(),
                if (operation.name.startsWith("FINAL_")) {
                    AiBudgetExecutionKind.FINAL_ANALYSIS
                } else {
                    AiBudgetExecutionKind.PRECHECK
                },
                UUID.randomUUID(),
                1,
                UUID.randomUUID(),
                1,
                "5".repeat(64),
                "6".repeat(64),
            ),
            AiPhysicalCallSpec(
                operation,
                1,
                "7".repeat(64),
                Issue144PhysicalProfiles.values.getValue(operation),
                if (operation.name.startsWith("FINAL_")) UUID.randomUUID() else null,
            ),
            policy.fingerprint,
        )
}

/** Contract-frozen request profiles, intentionally independent from the loader implementation. */
internal object Issue144PhysicalProfiles {
    val values =
        mapOf(
            AiPhysicalOperation.PRECHECK_CLASSIFICATION to "c8d01d4a04aa077e0488400dc3b4791753b8428db48c6712aa78f903608a4dfc",
            AiPhysicalOperation.PRECHECK_COUNT to "658a65563b34d43f854cc47dcd93d274d23789745e718b5f7ef49e1b59e8e307",
            AiPhysicalOperation.PRECHECK_GENERATION to "86e4593b78ec903e1c9b4bbbffe204d2b8343e1752d2b6353703ce3fb9b65714",
            AiPhysicalOperation.FINAL_PRIMARY to "0a3fc94ba00d368b4e7c9a41d0b231faab5058aa893dc11082ef786fc0a08d04",
            AiPhysicalOperation.FINAL_FALLBACK to "9c5021916c80178f58d235e55bbbad4889875560b710a505fbde5dedd1a824ab",
        )
}
