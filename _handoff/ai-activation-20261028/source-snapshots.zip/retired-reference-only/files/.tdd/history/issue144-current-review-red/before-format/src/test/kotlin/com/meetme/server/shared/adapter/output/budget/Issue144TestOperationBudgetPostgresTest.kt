package com.meetme.server.shared.adapter.output.budget

import com.meetme.server.shared.adapter.output.persistence.JdbcAiTestOperationCampaignAdapter
import com.meetme.server.shared.adapter.output.persistence.JdbcDurableAiBudgetRepository
import com.meetme.server.shared.application.port.output.AiBudgetAuthorityRegistryPort
import com.meetme.server.shared.application.port.output.AiBudgetBillRequest
import com.meetme.server.shared.application.port.output.AiBudgetDispatchRequest
import com.meetme.server.shared.application.port.output.AiBudgetObservation
import com.meetme.server.shared.application.port.output.AiBudgetOutcome
import com.meetme.server.shared.application.port.output.AiBudgetQuoteRequest
import com.meetme.server.shared.application.port.output.AiBudgetReserveRequest
import com.meetme.server.shared.application.port.output.AiBudgetSettlementRequest
import com.meetme.server.shared.application.port.output.AiBudgetUnit
import com.meetme.server.shared.application.port.output.AiPhysicalOperation
import com.meetme.server.shared.application.port.output.AiTestOperationCampaign
import com.meetme.server.shared.application.port.output.AiTestOperationCampaignPort
import com.meetme.server.shared.application.port.output.AiVerifiedBudgetQuote
import com.meetme.server.shared.application.port.output.AiVerifiedCompleteBill
import com.meetme.server.shared.application.port.output.AiVerifiedFinalReserve
import com.meetme.server.shared.application.port.output.DurableAiBudgetRepository
import com.meetme.server.shared.application.service.DurableAiBudgetService
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import org.junit.jupiter.api.assertThrows
import java.math.BigInteger
import java.util.UUID
import java.util.concurrent.Callable
import java.util.concurrent.CyclicBarrier
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** #144 synthetic admitted executions and actual PG budget/campaign transactions; no provider transport. */
class Issue144TestOperationBudgetPostgresTest : DurableBudgetPostgresFixture() {
    private val requestUnit = AiBudgetUnit("TEST_PHYSICAL_REQUEST", 0)

    private fun campaign(maximum: Long = 20): AiTestOperationCampaign {
        val id = UUID.randomUUID()
        return AiTestOperationCampaign(id, hash("synthetic-test-policy:$id"), maximum, NOW.minusSeconds(1), NOW.plusSeconds(120))
    }

    private fun testRoom(campaign: AiTestOperationCampaign): UUID =
        ready(BigInteger.valueOf(campaign.maximumRequests) + BigInteger.ONE).also {
            jdbc.update(
                "UPDATE ai_room_budgets SET unit_code='TEST_PHYSICAL_REQUEST',unit_scale=0,policy_fingerprint=? WHERE room_id=?",
                campaign.policyFingerprint,
                it,
            )
        }

    private fun requestFor(
        room: UUID,
        operation: AiPhysicalOperation = AiPhysicalOperation.PRECHECK_CLASSIFICATION,
    ): AiBudgetReserveRequest = request(room, operation).also { fence.allow(it.execution) }

    private fun authority(campaign: AiTestOperationCampaign): AiBudgetAuthorityRegistryPort =
        object : AiBudgetAuthorityRegistryPort {
            override fun quote(request: AiBudgetQuoteRequest): AiVerifiedBudgetQuote =
                AiVerifiedBudgetQuote(
                    hash("test-quote:${request.execution.executionId}:${request.call}"),
                    request.call.profileFingerprint,
                    request.call.wholePayloadFingerprint,
                    campaign.policyFingerprint,
                    hash("test-config:${campaign.id}"),
                    BigInteger.ONE,
                    requestUnit,
                    campaign.expiresAt,
                    campaign.id,
                )

            override fun protectedFinalReserve(request: AiBudgetQuoteRequest): AiVerifiedFinalReserve =
                AiVerifiedFinalReserve(campaign.policyFingerprint, bi(5), requestUnit, campaign.expiresAt)

            override fun testOperationCampaign(policyFingerprint: String): AiTestOperationCampaign? =
                campaign.takeIf { it.policyFingerprint == policyFingerprint }

            override fun completeBill(request: AiBudgetBillRequest): AiVerifiedCompleteBill? = null
        }

    private fun service(
        campaign: AiTestOperationCampaign,
        registry: AiBudgetAuthorityRegistryPort = authority(campaign),
        campaigns: AiTestOperationCampaignPort? = JdbcAiTestOperationCampaignAdapter(jdbc, clock),
        repository: DurableAiBudgetRepository = JdbcDurableAiBudgetRepository(jdbc),
    ): DurableAiBudgetService = DurableAiBudgetService(repository, clock, fence, registry, campaigns)

    private fun reserve(
        service: DurableAiBudgetService,
        request: AiBudgetReserveRequest,
    ) = assertDoesNotThrow { transaction.execute { service.reserve(request) } }

    private fun assertCampaignUsed(
        campaign: AiTestOperationCampaign,
        used: Long,
    ) {
        val remaining = campaign.maximumRequests - used
        assertTrue(
            assertDoesNotThrow {
                transaction.execute {
                    JdbcAiTestOperationCampaignAdapter(jdbc, clock).reserve(campaign, remaining, NOW.plusSeconds(60))
                }
            } == true,
            "The conservative reserved count must match exactly, including protected final capacity",
        )
        assertFalse(
            assertDoesNotThrow {
                transaction.execute {
                    JdbcAiTestOperationCampaignAdapter(jdbc, clock).reserve(campaign, 1, NOW.plusSeconds(60))
                }
            } == true,
        )
    }

    @Test
    fun `TO20 first personal request really reserves five final slots and replay never tops up or double-debits`() {
        val campaign = campaign(10)
        val room = testRoom(campaign)
        val service = service(campaign)
        val request = requestFor(room)
        val first = assertNotNull(reserve(service, request))
        assertEquals(5, snapshot(room).testFinalSlots)
        assertEquals(BigInteger.ONE, snapshot(room).held)
        assertEquals(first, reserve(service, request))
        assertEquals(5, snapshot(room).testFinalSlots)
        assertEquals(BigInteger.ONE, snapshot(room).held)
        assertCampaignUsed(campaign, 6)
    }

    @Test
    fun `TO21 finals consume protected slots and the next personal request replenishes only the missing slots`() {
        val campaign = campaign(20)
        val room = testRoom(campaign)
        val service = service(campaign)
        assertNotNull(reserve(service, requestFor(room)))
        val final = requestFor(room, AiPhysicalOperation.FINAL_PRIMARY)
        val reservedFinal = assertNotNull(reserve(service, final))
        assertEquals(4, snapshot(room).testFinalSlots)
        assertEquals(reservedFinal, reserve(service, final), "Final replay cannot consume another protected slot")
        assertEquals(4, snapshot(room).testFinalSlots)
        assertNotNull(reserve(service, requestFor(room)))
        assertEquals(5, snapshot(room).testFinalSlots)
        assertEquals(bi(3), snapshot(room).held)
        assertCampaignUsed(campaign, 8)
    }

    @Test
    fun `TO21 a final request without unused protection debits a new campaign slot once`() {
        val campaign = campaign(10)
        val room = testRoom(campaign)
        val service = service(campaign)
        val request = requestFor(room, AiPhysicalOperation.FINAL_PRIMARY)
        val first = assertNotNull(reserve(service, request))
        assertEquals(0, snapshot(room).testFinalSlots)
        assertEquals(BigInteger.ONE, snapshot(room).held)
        assertEquals(first, reserve(service, request))
        assertCampaignUsed(campaign, 1)
    }

    @Test
    fun `TO22 extending a partly replayed personal group debits only its new physical child`() {
        val campaign = campaign(10)
        val room = testRoom(campaign)
        val service = service(campaign)
        val count = requestFor(room, AiPhysicalOperation.PRECHECK_COUNT)
        val first = assertNotNull(reserve(service, count)).calls.single()
        val group = count.copy(calls = count.calls + requestFor(room, AiPhysicalOperation.PRECHECK_GENERATION).calls.single())
        val extended = assertNotNull(reserve(service, group))
        assertEquals(first, extended.calls.first())
        assertEquals(extended, reserve(service, group))
        assertEquals(5, snapshot(room).testFinalSlots)
        assertEquals(bi(2), snapshot(room).held)
        assertCampaignUsed(campaign, 7)
    }

    @Test
    fun `TO22 two-child personal admission reserves its common protection once and refuses the whole group at global limit`() {
        for (maximum in listOf(6L, 7L)) {
            val campaign = campaign(maximum)
            val room = testRoom(campaign)
            val first = requestFor(room, AiPhysicalOperation.PRECHECK_COUNT)
            val group = first.copy(calls = first.calls + requestFor(room, AiPhysicalOperation.PRECHECK_GENERATION).calls.single())
            val reservation = reserve(service(campaign), group)
            if (maximum == 6L) {
                assertNull(reservation)
                assertEquals(BigInteger.ZERO, snapshot(room).held)
                assertEquals(0, snapshot(room).testFinalSlots)
                assertCampaignUsed(campaign, 0)
            } else {
                assertEquals(2, assertNotNull(reservation).calls.size)
                assertEquals(5, snapshot(room).testFinalSlots)
                assertEquals(bi(2), snapshot(room).held)
                assertCampaignUsed(campaign, 7)
            }
        }
    }

    @Test
    fun `TO23 two rooms racing for six remaining global slots admit only one new personal request`() {
        val campaign = campaign(6)
        val requests = List(2) { requestFor(testRoom(campaign)) }
        val barrier = CyclicBarrier(2)
        val pool = Executors.newFixedThreadPool(2)
        try {
            val admitted =
                requests
                    .map { request ->
                        pool.submit(
                            Callable {
                                barrier.await(5, TimeUnit.SECONDS)
                                reserve(service(campaign), request)
                            },
                        )
                    }.map { assertDoesNotThrow { it.get(15, TimeUnit.SECONDS) } }
            assertEquals(1, admitted.count { it != null })
            assertEquals(1, requests.count { snapshot(it.execution.roomId).testFinalSlots == 5 })
            assertCampaignUsed(campaign, 6)
        } finally {
            pool.shutdownNow()
            assertTrue(pool.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    @Test
    fun `TO24 tagged test quote never silently falls back to a missing port or missing campaign authority`() {
        val campaign = campaign()
        val room = testRoom(campaign)
        val request = requestFor(room)
        assertNull(reserve(service(campaign, campaigns = null), request))
        val approved = authority(campaign)
        val missing =
            object : AiBudgetAuthorityRegistryPort by approved {
                override fun testOperationCampaign(policyFingerprint: String): AiTestOperationCampaign? = null
            }
        assertNull(reserve(service(campaign, registry = missing), request))
        assertEquals(BigInteger.ZERO, snapshot(room).held)
        assertEquals(0, snapshot(room).testFinalSlots)
        assertCampaignUsed(campaign, 0)
    }

    @Test
    fun `TO24 missing test tag foreign campaign wrong unit and nonunit quote deny all child reservations`() {
        for (fault in listOf("MISSING_ID", "FOREIGN_ID", "SCALE", "AMOUNT_ZERO", "AMOUNT_TWO")) {
            val campaign = campaign()
            val room = testRoom(campaign)
            val request = requestFor(room)
            val approved = authority(campaign)
            val altered =
                object : AiBudgetAuthorityRegistryPort by approved {
                    override fun quote(request: AiBudgetQuoteRequest): AiVerifiedBudgetQuote =
                        assertNotNull(approved.quote(request)).let {
                            when (fault) {
                                "MISSING_ID" -> it.copy(testCampaignId = null)
                                "FOREIGN_ID" -> it.copy(testCampaignId = UUID.randomUUID())
                                "SCALE" -> it.copy(unit = requestUnit.copy(scale = 1))
                                "AMOUNT_ZERO" -> it.copy(maximumAmount = BigInteger.ZERO)
                                else -> it.copy(maximumAmount = bi(2))
                            }
                        }
                }
            assertNull(reserve(service(campaign, registry = altered), request), fault)
            assertEquals(BigInteger.ZERO, snapshot(room).held)
            assertEquals(0, snapshot(room).testFinalSlots)
            assertCampaignUsed(campaign, 0)
        }
    }

    @Test
    fun `TO25 late validation failure leaves no committed campaign debit or final protection`() {
        val campaign = campaign()
        val room = testRoom(campaign)
        val request = requestFor(room)
        val base = JdbcDurableAiBudgetRepository(jdbc)
        val slowProfile =
            object : DurableAiBudgetRepository by base {
                override fun insertProfile(
                    snapshotFingerprint: String,
                    quote: AiVerifiedBudgetQuote,
                ): Boolean {
                    val inserted = base.insertProfile(snapshotFingerprint, quote)
                    clock.set(campaign.expiresAt)
                    return inserted
                }
            }
        assertNull(reserve(service(campaign, repository = slowProfile), request))
        clock.set(NOW)
        assertEquals(BigInteger.ZERO, snapshot(room).held)
        assertEquals(0, snapshot(room).testFinalSlots)
        assertCampaignUsed(campaign, 0)
    }

    @Test
    fun `TO24 mixed test and untagged or foreign-campaign children are rejected as a whole group`() {
        for (foreign in listOf(false, true)) {
            val campaign = campaign()
            val room = testRoom(campaign)
            val count = requestFor(room, AiPhysicalOperation.PRECHECK_COUNT)
            val group = count.copy(calls = count.calls + requestFor(room, AiPhysicalOperation.PRECHECK_GENERATION).calls.single())
            val approved = authority(campaign)
            val mixed =
                object : AiBudgetAuthorityRegistryPort by approved {
                    override fun quote(request: AiBudgetQuoteRequest): AiVerifiedBudgetQuote =
                        assertNotNull(approved.quote(request)).let {
                            if (request.call.operation == AiPhysicalOperation.PRECHECK_GENERATION) {
                                it.copy(testCampaignId = if (foreign) UUID.randomUUID() else null)
                            } else {
                                it
                            }
                        }
                }
            assertNull(reserve(service(campaign, registry = mixed), group))
            assertEquals(BigInteger.ZERO, snapshot(room).held)
            assertEquals(0, snapshot(room).testFinalSlots)
            assertCampaignUsed(campaign, 0)
        }
    }

    @Test
    fun `TO26 second child database failure rolls back the campaign budget and every first-child insert`() {
        val campaign = campaign()
        val room = testRoom(campaign)
        val first = requestFor(room, AiPhysicalOperation.PRECHECK_COUNT)
        val group = first.copy(calls = first.calls + requestFor(room, AiPhysicalOperation.PRECHECK_GENERATION).calls.single())
        jdbc.execute(
            "CREATE FUNCTION issue144_group_failure() RETURNS trigger LANGUAGE plpgsql AS " +
                "'BEGIN IF NEW.operation=''PRECHECK_GENERATION'' THEN RAISE EXCEPTION ''synthetic group failure''; " +
                "END IF; RETURN NEW; END'",
        )
        jdbc.execute(
            "CREATE TRIGGER issue144_group_failure BEFORE INSERT ON ai_call_reservations " +
                "FOR EACH ROW EXECUTE FUNCTION issue144_group_failure()",
        )
        try {
            assertThrows<RuntimeException> { transaction.execute { service(campaign).reserve(group) } }
        } finally {
            jdbc.execute("DROP TRIGGER issue144_group_failure ON ai_call_reservations")
            jdbc.execute("DROP FUNCTION issue144_group_failure()")
        }
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM ai_call_reservations WHERE room_id=?", Int::class.java, room))
        assertEquals(BigInteger.ZERO, snapshot(room).held)
        assertEquals(0, snapshot(room).testFinalSlots)
        assertCampaignUsed(campaign, 0)
    }

    @Test
    fun `TO27 expiry blocks a reserved call claim while committed conservative slots never refund on deletion`() {
        val campaign = campaign(6)
        val room = testRoom(campaign)
        val request = requestFor(room)
        val service = service(campaign)
        val call = assertNotNull(reserve(service, request)).calls.single()
        clock.set(campaign.expiresAt)
        assertNull(
            assertDoesNotThrow {
                transaction.execute {
                    service.claim(AiBudgetDispatchRequest(call.reservationId, request.execution, call.call))
                }
            },
        )
        clock.set(NOW)
        jdbc.update("DELETE FROM meeting_rooms WHERE id=?", room)
        assertCampaignUsed(campaign, 6)
    }

    @Test
    fun `TO27 claim needs the current exact campaign and durable counter without consuming a second slot`() {
        for (fault in listOf("MISSING_AUTHORITY", "MISSING_PORT", "CAMPAIGN_ID", "POLICY", "MAXIMUM", "INTERVAL")) {
            val campaign = campaign(10)
            val room = testRoom(campaign)
            val request = requestFor(room)
            val approvedService = service(campaign)
            val call = assertNotNull(reserve(approvedService, request)).calls.single()
            val approved = authority(campaign)
            val altered =
                object : AiBudgetAuthorityRegistryPort by approved {
                    override fun testOperationCampaign(policyFingerprint: String): AiTestOperationCampaign? =
                        when (fault) {
                            "MISSING_AUTHORITY" -> null
                            "CAMPAIGN_ID" -> campaign.copy(id = UUID.randomUUID())
                            "POLICY" -> campaign.copy(policyFingerprint = hash("other-policy"))
                            "MAXIMUM" -> campaign.copy(maximumRequests = campaign.maximumRequests + 1)
                            "INTERVAL" -> campaign.copy(expiresAt = campaign.expiresAt.plusSeconds(1))
                            else -> campaign
                        }
                }
            val guarded =
                service(
                    campaign,
                    registry = altered,
                    campaigns = if (fault == "MISSING_PORT") null else JdbcAiTestOperationCampaignAdapter(jdbc, clock),
                )
            val dispatch = AiBudgetDispatchRequest(call.reservationId, request.execution, call.call)
            assertNull(assertDoesNotThrow { transaction.execute { guarded.claim(dispatch) } }, fault)
            assertNotNull(
                assertDoesNotThrow { transaction.execute { approvedService.claim(dispatch) } },
                "A denied claim cannot consume the RESERVED to DISPATCH_INTENT permit",
            )
            assertNull(assertDoesNotThrow { transaction.execute { approvedService.claim(dispatch) } })
            assertEquals(BigInteger.ONE, snapshot(room).held)
            assertEquals(5, snapshot(room).testFinalSlots)
            assertCampaignUsed(campaign, 6)
        }
    }

    @Test
    fun `TO27 nanosecond expiry survives PostgreSQL reservation hydration and exact claim comparison`() {
        val campaign =
            campaign(10).copy(
                startsAt = NOW.minusSeconds(1).plusNanos(123456789),
                expiresAt = NOW.plusSeconds(120).plusNanos(987654321),
            )
        val room = testRoom(campaign)
        val request = requestFor(room)
        val service = service(campaign)
        val call = assertNotNull(reserve(service, request)).calls.single()
        val stored = assertNotNull(JdbcDurableAiBudgetRepository(jdbc).findCall(call.reservationId))
        assertEquals(
            campaign.expiresAt,
            stored.quote.validUntil,
            "PostgreSQL timestamptz microsecond precision cannot alter the exact TEST campaign quote",
        )
        val dispatch = AiBudgetDispatchRequest(call.reservationId, request.execution, call.call)
        assertNotNull(assertDoesNotThrow { transaction.execute { service.claim(dispatch) } })
        assertNull(assertDoesNotThrow { transaction.execute { service.claim(dispatch) } })
        assertEquals(5, snapshot(room).testFinalSlots)
        assertCampaignUsed(campaign, 6)
    }

    @Test
    fun `TO28 observed failures and a later monetary authority cannot settle or refund a persisted test reservation`() {
        val campaign = campaign(10)
        val room = testRoom(campaign)
        val request = requestFor(room)
        val service = service(campaign)
        val call = assertNotNull(reserve(service, request)).calls.single()
        val permit =
            assertNotNull(
                assertDoesNotThrow {
                    transaction.execute {
                        service.claim(AiBudgetDispatchRequest(call.reservationId, request.execution, call.call))
                    }
                },
            )
        assertTrue(
            assertDoesNotThrow {
                transaction.execute {
                    service.observe(
                        AiBudgetObservation(call.reservationId, permit.dispatchToken, UUID.randomUUID(), AiBudgetOutcome.UNKNOWN),
                    )
                }
            } == true,
        )
        assertTrue(
            assertDoesNotThrow {
                transaction.execute {
                    service.observe(
                        AiBudgetObservation(call.reservationId, permit.dispatchToken, UUID.randomUUID(), AiBudgetOutcome.FAILED),
                    )
                }
            } == true,
        )
        val lateMoney =
            object : AiBudgetAuthorityRegistryPort by authority(campaign) {
                override fun testOperationCampaign(policyFingerprint: String): AiTestOperationCampaign? = null

                override fun completeBill(request: AiBudgetBillRequest): AiVerifiedCompleteBill =
                    AiVerifiedCompleteBill(request.quoteFingerprint, hash("not-a-test-bill"), BigInteger.ZERO, requestUnit)
            }
        assertFalse(
            assertDoesNotThrow {
                transaction.execute {
                    this.service(campaign, registry = lateMoney).settle(
                        AiBudgetSettlementRequest(call.reservationId, permit.dispatchToken, "not-money"),
                    )
                }
            } == true,
        )
        assertEquals(BigInteger.ONE, snapshot(room).held)
        assertEquals(BigInteger.ZERO, snapshot(room).settled)
        assertEquals(5, snapshot(room).testFinalSlots)
        assertCampaignUsed(campaign, 6)
    }
}
