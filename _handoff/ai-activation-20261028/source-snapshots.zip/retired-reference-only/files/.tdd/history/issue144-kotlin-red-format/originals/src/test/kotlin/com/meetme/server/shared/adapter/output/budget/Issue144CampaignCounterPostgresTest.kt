package com.meetme.server.shared.adapter.output.budget

import com.meetme.server.shared.adapter.output.persistence.JdbcAiTestOperationCampaignAdapter
import com.meetme.server.shared.application.port.output.AiTestOperationCampaign
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertDoesNotThrow
import java.time.Duration
import java.time.Instant
import java.util.UUID
import java.util.concurrent.Callable
import java.util.concurrent.CyclicBarrier
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

/** #144 actual PG cumulative admission; no pricing evidence and no provider/network operation. */
class Issue144CampaignCounterPostgresTest : DurableBudgetPostgresFixture() {
    private fun campaign(maximum: Long = 6): AiTestOperationCampaign {
        val id = UUID.randomUUID()
        return AiTestOperationCampaign(id, hash("synthetic-test-campaign:$id"), maximum, NOW.minusSeconds(1), NOW.plusSeconds(120))
    }

    private fun reserve(
        campaign: AiTestOperationCampaign,
        additional: Long,
        deadline: Instant = NOW.plusSeconds(60),
    ): Boolean =
        assertDoesNotThrow {
            transaction.execute { JdbcAiTestOperationCampaignAdapter(jdbc, clock).reserve(campaign, additional, deadline) }!!
        }

    @Test
    fun `TO10 exact campaign capacity is usable once and zero validation cannot reset it`() {
        val campaign = campaign(6)
        assertTrue(reserve(campaign, 2))
        assertTrue(reserve(campaign, 0))
        assertTrue(reserve(campaign, 4))
        assertFalse(reserve(campaign, 1))
        assertTrue(reserve(campaign, 0), "Validation of an active full campaign does not grant another slot")
        assertFalse(reserve(campaign, 1))
    }

    @Test
    fun `TO11 negative deltas invalid campaigns and overflow never wrap or reset cumulative usage`() {
        val campaign = campaign(2)
        assertFalse(reserve(campaign, -1))
        assertFalse(reserve(campaign.copy(maximumRequests = 0), 0))
        assertFalse(reserve(campaign.copy(maximumRequests = -1), 0))
        assertFalse(reserve(campaign.copy(policyFingerprint = "not-a-sha256"), 0))
        assertTrue(reserve(campaign, 2))
        assertFalse(reserve(campaign, Long.MAX_VALUE))
        assertFalse(reserve(campaign, 1))
        val largest = campaign(Long.MAX_VALUE)
        assertTrue(reserve(largest, 1))
        assertFalse(reserve(largest, Long.MAX_VALUE), "Check delta against maximum-used before doing signed addition")
        assertTrue(reserve(largest, Long.MAX_VALUE - 1))
        assertFalse(reserve(largest, 1))
    }

    @Test
    fun `TO12 campaign configuration is immutable across registry changes and adapter recreation`() {
        val original = campaign(6)
        assertTrue(reserve(original, 1))
        for (changed in listOf(
            original.copy(policyFingerprint = hash("different-artifact")),
            original.copy(maximumRequests = 7),
            original.copy(startsAt = original.startsAt.minusSeconds(1)),
            original.copy(expiresAt = original.expiresAt.plusSeconds(1)),
            original.copy(startsAt = original.startsAt.plusNanos(1)),
            original.copy(expiresAt = original.expiresAt.plusNanos(1)),
        )) {
            assertFalse(reserve(changed, 0), "A same-id configuration change cannot turn into a fresh campaign")
        }
        assertTrue(reserve(original, 5), "Recreating the JDBC adapter still observes the first cumulative counter")
        assertFalse(reserve(original, 1))
    }

    @Test
    fun `TO13 future expired and elapsed execution deadlines refuse both new reservation and zero-delta claim validation`() {
        val campaign = campaign()
        for (additional in listOf(0L, 1L)) {
            assertFalse(reserve(campaign().copy(startsAt = NOW.plusSeconds(1)), additional))
            assertFalse(reserve(campaign().copy(expiresAt = NOW), additional))
            assertFalse(reserve(campaign, additional, NOW))
            assertFalse(reserve(campaign, additional, NOW.minusNanos(1)))
        }
        assertTrue(reserve(campaign, 1))
        clock.set(campaign.expiresAt)
        assertFalse(reserve(campaign, 0, campaign.expiresAt.plusSeconds(60)))
        assertFalse(reserve(campaign, 1, campaign.expiresAt.plusSeconds(60)))
    }

    @Test
    fun `TO14 separate transactions racing for one campaign cannot overbook its last slots`() {
        val campaign = campaign(5)
        val barrier = CyclicBarrier(12)
        val pool = Executors.newFixedThreadPool(12)
        try {
            val results =
                (1..12)
                    .map {
                        pool.submit(
                            Callable {
                                barrier.await(5, TimeUnit.SECONDS)
                                reserve(campaign, 1)
                            },
                        )
                    }.map { assertDoesNotThrow { it.get(15, TimeUnit.SECONDS) } }
            assertEquals(5, results.count { it })
            assertFalse(reserve(campaign, 1))
        } finally {
            pool.shutdownNow()
            assertTrue(pool.awaitTermination(5, TimeUnit.SECONDS))
        }
    }

    @Test
    fun `TO15 transaction rollback restores the whole unsuccessful reservation but a successful debit never expires away`() {
        val campaign = campaign(3)
        transaction.executeWithoutResult { status ->
            assertTrue(assertDoesNotThrow { JdbcAiTestOperationCampaignAdapter(jdbc, clock).reserve(campaign, 3, NOW.plusSeconds(60)) })
            status.setRollbackOnly()
        }
        assertTrue(reserve(campaign, 3), "A rolled-back group must not strand campaign capacity")
        clock.advance(Duration.ofSeconds(1))
        assertFalse(reserve(campaign, 1), "Time passing or a fresh adapter cannot replenish committed usage")
    }

    @Test
    fun `TO16 room retention cannot cascade-delete the campaign counter`() {
        val campaign = campaign(3)
        assertTrue(reserve(campaign, 3))
        room()
        jdbc.execute("TRUNCATE meeting_rooms CASCADE")
        assertFalse(reserve(campaign, 1), "Global campaign state cannot be owned or cascaded by a room")
    }

    @Test
    fun `TO17 time is reread after waiting for the campaign row lock rather than before waiting`() {
        val campaign = campaign(1)
        val pool = Executors.newSingleThreadExecutor()
        lateinit var waiting: Future<Boolean>
        try {
            transaction.executeWithoutResult {
                assertTrue(assertDoesNotThrow { JdbcAiTestOperationCampaignAdapter(jdbc, clock).reserve(campaign, 0, NOW.plusSeconds(60)) })
                waiting = pool.submit(Callable { reserve(campaign, 1, campaign.expiresAt.plusSeconds(60)) })
                val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
                var locked = false
                while (System.nanoTime() < until && !waiting.isDone) {
                    locked = jdbc.queryForObject(
                        "SELECT count(*) FROM pg_stat_activity " +
                            "WHERE datname=current_database() AND pid<>pg_backend_pid() AND wait_event_type='Lock'",
                        Int::class.java,
                    )!! > 0
                    if (locked) break
                    Thread.sleep(10)
                }
                assertTrue(locked, "A cumulative campaign reservation must serialize on the existing row")
                clock.set(campaign.expiresAt)
            }
            assertFalse(
                assertDoesNotThrow { waiting.get(10, TimeUnit.SECONDS) },
                "The clock captured before acquiring a blocked row cannot authorize an already expired campaign",
            )
        } finally {
            pool.shutdownNow()
            assertTrue(pool.awaitTermination(5, TimeUnit.SECONDS))
        }
    }
}
