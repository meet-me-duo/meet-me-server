"""#144 reviewed test-operation artifact contract; all values are synthetic.

Run on Linux/WSL with real Bash, Python and jq. The renderer's aws executable is
an isolated fixture which serves only local synthetic values. No paid provider,
host deployment, database, SSM or other network service is invoked.
"""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[2]
DEPLOY = ROOT / "deploy"


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, DEPLOY / "pipeline" / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PUBLISHER = load("issue144_publisher", "publish_manifest.py")
DRIVER = load("issue144_driver", "run-approved-release.py")
APPROVAL = load("issue144_approval", "approved_release.py")
HOST = load("issue144_host", "host-approved-release.py")
PARSERS = {"publisher": PUBLISHER, "driver": DRIVER, "host": HOST}
V19 = "V19__add_ai_test_operation_campaigns.sql"
# Published bbf3a836 Git blob hashes; normalize only core.autocrlf checkout conversion.
HISTORICAL_SHA256 = {
    "V1__create_core_domain.sql": "f840adc70a59de4f7085f419f4063c34f5ed96e87a54b2aa4f052c15df023515",
    "V2__add_anonymous_room_lifecycle.sql": "75535992de90d7eedc1700487503418a300df6ca668eb18d517646517ebd40e7",
    "V3__add_submission_gemini_pipeline.sql": "a1d7723e2461dbc6e483040f24fe9df8efc5d088b9ddc00ffaf1cdc842f12371",
    "V4__add_matching_results.sql": "14f90ca0642a4ee02242d334ebe542503907b509ee1a4fdfcc45f6c33905fe9d",
    "V5__remove_meeting_duration.sql": "7127e1ccc1284865cc3b0ea38be3582a1870f7d3ec05e3700d4577d1084c3146",
    "V6__add_reliable_outbox_processing.sql": "526c1cca68d23c1ee9fe4fad6c7cf0937eb53df5e306ee75b327223855f8af7a",
    "V7__resume_delayed_matching_from_structuring.sql": "d252715c33435f88498e8e0131ea5b35e6e081e63fdc91fab67b7f1b6235c747",
    "V8__add_input_revision_rounds.sql": "04ac022f09473e4d95128c765b2e274b7d1d1abb0fee4b722f56119638d22a92",
    "V9__add_time_recommendations.sql": "a6fc046611fb3cafa96d51f87de09687b3fdecc403988d211b7d86c4fad0585d",
    "V10__add_bounded_analysis_invocations.sql": "694940de9100b58bc4a1ca2889d5d44fbd86221dead6805082b2c7999ee002ab",
    "V11__add_accounts_and_participant_ownership.sql": "0431b2c18a5f03c341d3d4c4d1f3456e169db610cb5bd92e3681978623b3b92c",
    "V12__add_guest_reaccess.sql": "fce24fe4bb215ef2d40d0b2eddb2efd1fc98d57162681d5050236824a3cd11da",
    "V13__add_submission_clarifications.sql": "b6ea047b7aa87486941b06d5cfbd4873449821ba6d684a8f52946053aa53e3ff",
    "V14__add_operator_access_audits.sql": "cddce45ef10fc2eac99cb739a1b631f41634b2cd06905e19919692844ca40196",
    "V15__add_parser_transport_observations.sql": "fcbcd040cb232ca400cbfb24b944f8289428032daf6ce386c35dbc119f9b9f98",
    "V16__add_pre_submission_checks.sql": "65dd8b5831ced11f62bf00eb21fc5eb61bc34356c7d99da2228b8fdd80d8358e",
    "V17__add_durable_ai_room_budgets.sql": "912b8f227e6ea7c20fc05cf96d705982fb9737c5051c7c07e771494df482834b",
    "V18__align_recommendation_selection_attendance.sql": "67061520a8fb4a96412ec1b82e7b6a4d07a4ab7745187d0fc1c9c759b45eec27",
}
SCRIPTS = tuple(HISTORICAL_SHA256) + (V19,)
REPOSITORY = "123456789012.dkr.ecr.ap-northeast-2.amazonaws.com/meet-me/server"
ENVIRONMENT = {"SOURCE_SHA": "a" * 40, "BUILD_RUN_ID": "144", "BUILD_RUN_ATTEMPT": "1",
               "ECR_REPOSITORY_URL": REPOSITORY, "IMAGE_DIGEST": "sha256:" + "b" * 64,
               "CI_RUN_ID": "143", "CI_SHA": "a" * 40}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def test_policy(**overrides):
    # These are fixture data, never selected operating values or a release artifact.
    return {"protocol": "meetme-managed-ai-policy-v1", "state": "TEST_OPERATION",
            "campaignId": "123e4567-e89b-12d3-a456-426614174000",
            "startsAt": "2020-01-01T00:00:00Z", "expiresAt": "2020-01-02T00:00:00Z",
            "maximumRequests": 7, "minimumConfidence": 0.6} | overrides


def configured_policy():
    profiles = {
        "PRECHECK_CLASSIFICATION": "c8d01d4a04aa077e0488400dc3b4791753b8428db48c6712aa78f903608a4dfc",
        "PRECHECK_COUNT": "658a65563b34d43f854cc47dcd93d274d23789745e718b5f7ef49e1b59e8e307",
        "PRECHECK_GENERATION": "86e4593b78ec903e1c9b4bbbffe204d2b8343e1752d2b6353703ce3fb9b65714",
        "FINAL_PRIMARY": "0a3fc94ba00d368b4e7c9a41d0b231faab5058aa893dc11082ef786fc0a08d04",
        "FINAL_FALLBACK": "9c5021916c80178f58d235e55bbbad4889875560b710a505fbde5dedd1a824ab",
    }
    return {"protocol": "meetme-managed-ai-policy-v1", "state": "CONFIGURED",
            "unit": {"code": "SYNTHETIC_REVIEW_UNIT", "scale": 0}, "roomCap": "100",
            "minimumConfidence": 0.6, "operations": [
                {"operation": operation, "profileFingerprint": fingerprint,
                 "evidenceFingerprint": "e" * 64, "maximumAmount": "1", "validUntil": "2099-01-01T00:00:00Z"}
                for operation, fingerprint in profiles.items()]}


def invalid_policies():
    base = test_policy()
    for key in base:
        yield "missing-" + key, canonical({k: v for k, v in base.items() if k != key})
    for key, value in (("roomCap", "1"), ("unit", {"code": "USD", "scale": 0}),
                       ("operations", []), ("unknown", True)):
        yield "extra-" + key, canonical(base | {key: value})
    for value in ("123E4567-E89B-12D3-A456-426614174000", "123e4567e89b12d3a456426614174000",
                  "{123e4567-e89b-12d3-a456-426614174000}", " 123e4567-e89b-12d3-a456-426614174000", None, 1):
        yield "uuid-" + str(value), canonical(base | {"campaignId": value})
    for value in (0, -1, 2**63, True, False, "7", 7.0, None):
        yield "request-limit-" + str(value), canonical(base | {"maximumRequests": value})
    for value in (-0.01, 1.01, True, False, "0.6", None):
        yield "confidence-" + str(value), canonical(base | {"minimumConfidence": value})
    for literal in ("NaN", "Infinity", "-Infinity", "1e999", "1.00000000000000000001", "-1e-999"):
        yield "confidence-literal-" + literal, canonical(base).replace(b'"minimumConfidence":0.6', b'"minimumConfidence":' + literal.encode())
    for key in ("startsAt", "expiresAt"):
        for value in ("2020-01-01", "2020-01-01T00:00:00+00:00", "2020-01-01T00:00:00z",
                      "2020-02-30T00:00:00Z", "0000-01-01T00:00:00Z", "10000-01-01T00:00:00Z",
                      "2020-01-01T00:00:60Z", "2020-01-01T24:00:00Z",
                      "2020-01-01T00:00:00.1234567890Z", None, 1):
            yield key + "-" + str(value), canonical(base | {key: value})
    for start, end in ((base["startsAt"], base["startsAt"]), (base["expiresAt"], base["startsAt"]),
                       ("2020-01-01T00:00:00.123456789Z", "2020-01-01T00:00:00.123456788Z"),
                       ("2020-01-01T00:00:00.1Z", "2020-01-01T00:00:00.100000000Z")):
        yield "nonincreasing-time", canonical(base | {"startsAt": start, "expiresAt": end})
    yield "duplicate-key", canonical(base)[:-1] + b',"maximumRequests":7}'


class Issue144PolicyShapeTests(unittest.TestCase):
    def test_reviewed_exact_shape_is_readable_before_start_and_after_expiry(self):
        for name, module in PARSERS.items():
            for policy in (test_policy(), test_policy(startsAt="2090-01-01T00:00:00Z", expiresAt="2090-01-02T00:00:00Z")):
                with self.subTest(parser=name, start=policy["startsAt"]):
                    module._runtime_policy_bytes(canonical(policy))

    def test_numeric_and_nanosecond_boundaries_are_accepted(self):
        for name, module in PARSERS.items():
            for count in (1, 2**63 - 1):
                for confidence in (0, 1, 0.5):
                    with self.subTest(parser=name, count=count, confidence=confidence):
                        module._runtime_policy_bytes(canonical(test_policy(
                            maximumRequests=count, minimumConfidence=confidence,
                            startsAt="2020-01-01T00:00:00.123456788Z",
                            expiresAt="2020-01-01T00:00:00.123456789Z")))

    def test_calendar_extremes_and_one_nanosecond_intervals_are_readable(self):
        for name, module in PARSERS.items():
            for start, expiry in (("0001-01-01T00:00:00Z", "9999-12-31T23:59:59.999999999Z"),
                                  ("2020-01-01T00:00:00.000000001Z", "2020-01-01T00:00:00.000000002Z")):
                with self.subTest(parser=name, start=start):
                    module._runtime_policy_bytes(canonical(test_policy(startsAt=start, expiresAt=expiry)))

    def test_invalid_partial_coerced_ambiguous_or_monetary_fields_are_rejected(self):
        for name, module in PARSERS.items():
            for case, raw in invalid_policies():
                with self.subTest(parser=name, case=case), self.assertRaises(ValueError):
                    module._runtime_policy_bytes(raw)

    def test_unconfigured_and_existing_configured_money_contract_remain_readable(self):
        for name, module in PARSERS.items():
            for policy in ({"protocol": "meetme-managed-ai-policy-v1", "state": "UNCONFIGURED"}, configured_policy()):
                with self.subTest(parser=name, state=policy["state"]):
                    module._runtime_policy_bytes(canonical(policy))

    def test_checked_in_artifact_stays_unconfigured(self):
        self.assertEqual({"protocol": "meetme-managed-ai-policy-v1", "state": "UNCONFIGURED"},
                         json.loads((DEPLOY / "runtime-ai-policy.json").read_bytes()))


def manifest(versions=range(1, 20)):
    rows = [{"version": str(v), "script": SCRIPTS[v - 1], "checksum": v * 37} for v in versions]
    return {"protocol": "meet-me-approved-release-v1", "sourceSha": "a" * 40,
            "buildRunId": "144", "buildRunAttempt": "1", "imageRepository": REPOSITORY,
            "imageDigest": "sha256:" + "b" * 64, "releaseId": "a" * 40 + "-144-1",
            "archiveSha256": "c" * 64, "schemaFingerprint": "d" * 64,
            "guardFingerprint": "e" * 64, "migrations": rows,
            "origin": {"repository": "meet-me-duo/meet-me-server", "ref": "refs/heads/main", "workflow": "CI",
                       "event": "push", "conclusion": "success", "ciRunId": "143", "ciSha": "a" * 40}}


def record(artifact):
    return {name: artifact[name] for name in ("sourceSha", "buildRunId", "buildRunAttempt", "schemaFingerprint", "guardFingerprint")} | {
        "protocol": "meet-me-automatic-release-v1", "currentImage": REPOSITORY + "@sha256:" + "b" * 64,
        "history": [dict(row, success=True) for row in artifact["migrations"]]}


class Issue144CatalogTests(unittest.TestCase):
    def test_v19_is_additive_and_all_published_sql_bytes_stay_unchanged(self):
        directory = ROOT / "src/main/resources/db/migration"
        for script, fingerprint in HISTORICAL_SHA256.items():
            with self.subTest(script=script):
                self.assertEqual(fingerprint, digest((directory / script).read_bytes().replace(b"\r\n", b"\n")))
        self.assertTrue((directory / V19).is_file(), "#144 requires a new V19 migration")
        self.assertEqual(set(SCRIPTS), {path.name for path in directory.iterdir()})

    def test_current_manifest_accepts_exact_v1_to_v19(self):
        artifact = manifest()
        APPROVAL.validate_manifest(artifact, {key: artifact[key] for key in APPROVAL.EXPECTED_FIELDS})

    def test_current_host_record_accepts_exact_v1_to_v19(self):
        artifact = manifest()
        with patch.object(HOST.os.path, "lexists", return_value=True), patch.object(HOST, "_bytes", return_value=canonical(record(artifact))):
            self.assertEqual(record(artifact), HOST._record())

    def test_v19_catalog_rejects_gaps_extra_versions_wrong_name_and_failed_history(self):
        for versions in (list(range(1, 19)) + [20], list(range(1, 18)) + [19], list(range(1, 20)) + [19]):
            artifact = manifest()
            artifact["migrations"] = [{"version": str(v), "script": f"V{v}__synthetic.sql", "checksum": v} for v in versions]
            with self.subTest(versions=versions), self.assertRaises(ValueError):
                APPROVAL.validate_manifest(artifact, {key: artifact[key] for key in APPROVAL.EXPECTED_FIELDS})
        for field, value in (("script", "V19__different.sql"), ("success", False)):
            changed = record(manifest())
            changed["history"][-1][field] = value
            with self.subTest(field=field), patch.object(HOST.os.path, "lexists", return_value=True), \
                    patch.object(HOST, "_bytes", return_value=canonical(changed)), self.assertRaises(ValueError):
                HOST._record()

    def test_all_previously_published_catalogs_remain_readable(self):
        catalogs = [range(1, n + 1) for n in (10, 11, 12, 16, 17, 18)] + [
            list(range(1, 12)) + [13], list(range(1, 11)) + [14, 15], list(range(1, 12)) + [14, 15]]
        for versions in catalogs:
            artifact = manifest(versions)
            with self.subTest(versions=list(versions)):
                APPROVAL.validate_manifest(artifact, {key: artifact[key] for key in APPROVAL.EXPECTED_FIELDS})
                with patch.object(HOST.os.path, "lexists", return_value=True), patch.object(HOST, "_bytes", return_value=canonical(record(artifact))):
                    self.assertEqual(record(artifact), HOST._record())

    def test_actual_publisher_accepts_test_operation_and_exact_new_catalog(self):
        with tempfile.TemporaryDirectory(prefix="issue144-publish-") as temporary:
            root = Path(temporary)
            shutil.copytree(DEPLOY, root / "deploy", ignore=shutil.ignore_patterns("tests", "compiled", "__pycache__"))
            migrations = root / "src/main/resources/db/migration"
            migrations.mkdir(parents=True)
            for script in SCRIPTS:
                (migrations / script).write_bytes(b"-- synthetic catalog fixture\nSELECT 1;\n")
            policy = canonical(test_policy())
            (root / "deploy/runtime-ai-policy.json").write_bytes(policy)
            archive = root / "synthetic.tar.gz"
            archive.write_bytes(b"SYNTHETIC_ARCHIVE_REFERENCE")
            result = PUBLISHER.build_manifest(root, archive, ENVIRONMENT)
            self.assertEqual(list(SCRIPTS), [row["script"] for row in result["migrations"]])
            expected_guard = [{"path": name, "sha256": digest((root / "deploy" / name).read_bytes())} for name in PUBLISHER.GUARD_FILES]
            self.assertEqual(digest(canonical(expected_guard)), result["guardFingerprint"])
            before = result["guardFingerprint"]
            (root / "deploy/runtime-ai-policy.json").write_bytes(policy + b"\n")
            self.assertNotEqual(before, PUBLISHER.build_manifest(root, archive, ENVIRONMENT)["guardFingerprint"])

    def test_actual_package_verifier_checks_test_policy_and_exact_v19_bytes(self):
        with tempfile.TemporaryDirectory(prefix="issue144-package-") as temporary:
            files = {name: (DEPLOY / name).read_bytes() for name in DRIVER.CONTRACT_FILES}
            files.update({"runtime-ai-policy.json": canonical(test_policy()),
                          "runtime-provider-mode": b"gemini-luna-required\n",
                          "preflight/compiled/ReadOnlyFlywayProbe.class": bytes.fromhex("cafebabe")})
            for helper in ("scripts/render-runtime-env.sh", "scripts/export-certificate.sh"):
                files[helper] = (DEPLOY / helper).read_bytes()
            artifact = manifest()
            catalog = []
            for row in artifact["migrations"]:
                raw = ("-- synthetic " + row["version"] + "\nSELECT 1;\n").encode()
                files["migrations/" + row["script"]] = raw
                row["checksum"] = PUBLISHER.flyway_checksum(raw)
                catalog.append({"version": row["version"], "script": row["script"], "sha256": digest(raw)})
            artifact["guardFingerprint"] = digest(canonical([{"path": name, "sha256": digest(files[name])} for name in DRIVER.CONTRACT_FILES]))
            artifact["schemaFingerprint"] = digest(canonical(catalog))
            archive = Path(temporary) / "synthetic.tar.gz"
            with tarfile.open(archive, "w:gz") as packed:
                for name, raw in files.items():
                    item = tarfile.TarInfo(name)
                    item.size = len(raw)
                    item.mode = 0o755 if name in ("scripts/render-runtime-env.sh", "scripts/export-certificate.sh") else 0o644
                    packed.addfile(item, io.BytesIO(raw))
            self.assertTrue(DRIVER._verify_package(archive, artifact))
            artifact["migrations"][-1]["checksum"] += 1
            with self.assertRaises(ValueError):
                DRIVER._verify_package(archive, artifact)


AWS_FIXTURE = '''#!/usr/bin/env python3
import json,os,sys
args=sys.argv[1:]
def arg(name):return args[args.index(name)+1] if name in args else None
with open(os.environ['ISSUE144_CALLS'],'a') as stream:stream.write(json.dumps(args)+'\\n')
if args[:2]==['secretsmanager','get-secret-value']:
 print(json.dumps({'password':'synthetic-only-password'}));sys.exit(0)
if args[:2]!=['ssm','get-parameter']:sys.exit(98)
name=arg('--name');key=name.rsplit('/',1)[-1]
values={'precheck-provider-enabled':os.environ['ISSUE144_ENABLED'],'database-url':'jdbc:postgresql://fixture.invalid/fixture','redis-port':'6379','redis-ssl-enabled':'true'}
value=values.get(key,'synthetic-only-value')
if arg('--output')=='json':print(json.dumps({'Parameter':{'Type':'SecureString' if '/secret/' in name else 'String','Value':value}}))
else:print(value)
'''


class RendererFixture:
    def __init__(self, raw, enabled):
        self.temporary = tempfile.TemporaryDirectory(prefix="issue144-render-")
        self.root = Path(self.temporary.name)
        self.release = self.root / "release"
        (self.release / "scripts").mkdir(parents=True)
        (self.root / "bin").mkdir()
        shutil.copyfile(DEPLOY / "scripts/render-runtime-env.sh", self.release / "scripts/render-runtime-env.sh")
        (self.release / "runtime-provider-mode").write_text("gemini-luna-required\n")
        (self.release / "runtime-auth-mode").write_text("oauth-rs256-required\n")
        (self.release / "runtime-ai-policy.json").write_bytes(raw)
        executable = self.root / "bin/aws"
        executable.write_text(AWS_FIXTURE)
        executable.chmod(0o755)
        self.destination = self.root / ".env.runtime"
        self.destination.write_bytes(b"PREVIOUS_SYNTHETIC_ENV=preserved\n")
        self.destination.chmod(0o600)
        jq_directory = str(Path(shutil.which("jq")).parent)
        self.environment = {"PATH": str(self.root / "bin") + ":" + jq_directory + ":/usr/bin:/bin", "AWS_REGION": "synthetic-region",
                            "MEETME_PARAMETER_ROOT": "/synthetic/issue144", "ISSUE144_CALLS": str(self.root / "calls.jsonl"),
                            "ISSUE144_ENABLED": "true" if enabled else "false"}

    def render(self):
        return subprocess.run(["bash", str(self.release / "scripts/render-runtime-env.sh"), str(self.destination)],
                              env=self.environment, capture_output=True, text=True, timeout=10)

    def close(self):
        self.temporary.cleanup()


class Issue144ActualRendererTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        for executable in ("bash", "python3", "jq"):
            if shutil.which(executable) is None:
                raise RuntimeError("Renderer verification needs an existing " + executable + "; dependency failures are not RED")

    def test_test_operation_all_flags_threshold_and_raw_artifact_hash(self):
        for enabled in (False, True):
            for policy in (test_policy(), test_policy(startsAt="2090-01-01T00:00:00Z", expiresAt="2090-01-02T00:00:00Z")):
                raw = canonical(policy)
                fixture = RendererFixture(raw, enabled)
                try:
                    result = fixture.render()
                    self.assertEqual(0, result.returncode, result.stderr)
                    lines = dict(line.split("=", 1) for line in fixture.destination.read_text().splitlines())
                    for key in ("MEETME_PRECHECK_PROVIDER_ENABLED", "MEETME_PRECHECK_DECISIONROUTING_ENABLED",
                                "MEETME_PRECHECK_CLASSIFIER_ENABLED", "MEETME_AI_BUDGET_ENABLED"):
                        self.assertEqual(str(enabled).lower(), lines[key])
                    self.assertEqual(digest(raw), lines["MEETME_AI_BUDGET_POLICYSHA256"])
                    self.assertEqual("0.6" if enabled else None, lines.get("MEETME_PRECHECK_CLASSIFIER_MINIMUMCONFIDENCE"))
                    self.assertEqual(0o600, fixture.destination.stat().st_mode & 0o777)
                    self.assertEqual("", result.stdout)
                    self.assertNotIn("synthetic-only-password", result.stderr)
                finally:
                    fixture.close()

    def test_invalid_test_policy_preserves_previous_environment_before_provider_key_lookup(self):
        for case, raw in invalid_policies():
            with self.subTest(case=case):
                fixture = RendererFixture(raw, True)
                try:
                    result = fixture.render()
                    self.assertNotEqual(0, result.returncode)
                    self.assertIn("Managed AI runtime policy", result.stderr)
                    self.assertEqual(b"PREVIOUS_SYNTHETIC_ENV=preserved\n", fixture.destination.read_bytes())
                    self.assertEqual(0o600, fixture.destination.stat().st_mode & 0o777)
                    calls = [json.loads(line) for line in (fixture.root / "calls.jsonl").read_text().splitlines()]
                    self.assertFalse(any("/secret/typesafe-api-key" in argument for call in calls for argument in call))
                finally:
                    fixture.close()

    def test_unconfigured_off_and_configured_money_on_still_render(self):
        for policy, enabled in (({"protocol": "meetme-managed-ai-policy-v1", "state": "UNCONFIGURED"}, False),
                                (configured_policy(), True)):
            fixture = RendererFixture(canonical(policy), enabled)
            try:
                result = fixture.render()
                self.assertEqual(0, result.returncode, result.stderr)
            finally:
                fixture.close()


if __name__ == "__main__":
    unittest.main()
