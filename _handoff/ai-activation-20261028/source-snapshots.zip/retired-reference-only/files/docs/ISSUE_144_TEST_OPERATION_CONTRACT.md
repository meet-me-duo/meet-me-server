# #144 명시적 비금액 AI 테스트 운영 계약

사용자 결정: 정식 금액 정책은 테스트 운영 중 추후 결정한다. 이 구현은 금액 정책 확정을 선행조건으로 요구하지 않으며, 유료 검증 호출·운영 입력값 확정·설정 활성화를 실행하지 않는다. 현재 UNCONFIGURED 기본값과 기존 CONFIGURED 금전 경로를 보존한다.

## 설정 계약

`meetme-managed-ai-policy-v1`의 새 state `TEST_OPERATION`은 아래 필드만 가진다.

- `protocol`, `state`, `campaignId`(정규형 UUID)
- `startsAt`, `expiresAt`(UTC Z, startsAt < expiresAt)
- `maximumRequests`(양의 Long 정수, 기본값 없음)
- `minimumConfidence`(유한 0..1, 기본값 없음; 테스트 임계값이며 품질 보장이 아님)

기존 네 실행 flag의 allOFF/allON 일관성, threshold 일치를 유지한다. 설정 형식은 시작 전/만료 후에도 읽을 수 있으나 해당 기간에는 room 초기화·예약·claim을 거부한다. 운영 입력은 임의 생성하지 않고 실제 artifact는 UNCONFIGURED를 유지한다.

TEST_OPERATION은 고정 다섯 physical profile을 그대로 사용하고, 요청당 1개의 `TEST_PHYSICAL_REQUEST` 단위(scale 0)를 예약한다. 이는 청구 금액 quote가 아니다. admission evidence는 해당 검토된 테스트 설정과 profile의 지문이며 가격/실청구 근거로 표시하지 않는다. 테스트 예약은 금전 settle 대상이 아니다.

## 영속성과 불변식

새 V19는 방과 FK/cascade로 연결되지 않는 campaign config/cumulative reserved-slot counter를 둔다. campaignId의 설정 지문·최대 요청수·시작/만료는 최초 등록 뒤 불변이다. 재시작·동일 요청 replay·room 삭제/retention·실패/UNKNOWN·usage 관측은 counter를 감소시키거나 초기화하지 않는다. 같은 id의 다른 설정을 거부한다.

기존 예약에는 nullable test campaign id를, room budget에는 남은 시험 final 보호 slot(0..5)을 추가한다. 기존 행은 nullable/default0이며 과거 이력·상태·cap을 갱신하지 않는다. 신규 room만 기존 INSERT receipt/동일 transaction/epoch 검증을 통해 이 테스트 정책에 초기화한다.

기존 room→실행/claim→room budget 잠금 뒤 campaign row를 잠근다. 최신 clock으로 startsAt/expiry/실행 deadline을 다시 확인하고 counter 상한을 원자 검증한다. 묶음 예약은 전부 성공/전부 실패이고 DB 예외는 전체 transaction을 rollback한다. 새 호출만 slot을 소비하며 replay는 동일 reservation id를 반환한다. quote의 test id가 있으면 campaign 권한과 실제 port가 반드시 필요하고, 누락을 금전 경로로 처리하지 않는다.

새 개인 예약은 final 4+1을 위해 room의 남은 final slot을 5로 보충하는 데 필요한 slot과 새 개인 요청을 campaign에 함께 예약한다. 새 final 요청은 보호 slot이 있으면 하나를 소비하고, 없으면 campaign에서 새 slot을 소비한다. 이미 예약된 호출 replay는 재충전/중복 소비하지 않는다. room 삭제 때 미사용 보호분도 환불하지 않아 전체 상한이 되살아나지 않는다. 이 보수적 예약 수는 실제 HTTP 수/청구액과 구분한다.

기존 RESERVED→DISPATCH_INTENT CAS, endpoint/실제 payload fingerprint, owner/revision/generation/deadline/epoch, 입력·출력·시간·재시도·동시성 경계를 유지한다. claim 시 현재 campaign 유효성을 다시 검증한다. 기존 UNCONFIGURED/HISTORICAL_UNKNOWN room을 READY로 강제 승격하지 않는다.

## 검증과 완료 경계

- loader/flag/renderer/배포 validator의 state와 field 일관성, 잘못된/부분 설정 거부
- 기존 금전 경로와 UNCONFIGURED 기본 동작 유지
- PostgreSQL에서 여러 room의 한도 경쟁, 원자 그룹, replay/claim 경쟁, 재시작·삭제 후 누적 counter 유지
- 실패/UNKNOWN/expiry 후 환불0, 같은 campaign id 재설정 거부, final 보호분 유지
- 합성 provider만 사용하는 실제 managed graph의 사전확인/최종 dispatch, 외부 유료 요청0
- 독립 테스트 검토·경계별 결함 주입과 필수 검사

금액 상한 없이 실행하면 유한 요청 수가 있어도 누적 원화 청구액 상한을 보장하지 않는다. 실제 유료 검증은 별도 범위가 정해질 때까지 실행하지 않는다. 이 코드 준비는 신규 키/IAM/인증권한 변경이나 운영 배포/규칙 변경을 수행하는 단계가 아니다.

## 활성화 전에 필요한 최소 입력

- `[SHARED]` 시작·만료 시각: UTC 기간 밖의 신규 room·예약·claim을 거부하기 위한 기술 입력이다. 실제 기간은 아직 선택하지 않았다.
- `[SHARED]` `maximumRequests`: 전역 누적 요청 슬롯 수다. 개인 요청 1개를 처음 허용하려면 요청 1개와 final 보호 5개의 총 6개가 필요하다. 이는 실제 호출 횟수나 금전 상한과 같지 않다. 실제 슬롯 수는 아직 선택하지 않았다.
- `[SHARED]` `minimumConfidence`: 기존 classifier의 명시적 threshold 입력이다. 0..1 범위는 구조 검증이며 실모델 품질 근거가 아니다. 합성 테스트의 값은 운영 선택으로 사용하지 않는다.
- `[AGENT]` 위 값이 정해지면 새 canonical UUID를 생성하고 artifact SHA와 함께 고정한다. ID 변경으로 누적량을 초기화하는 운영 경로는 자동화하지 않는다.
- `[AGENT]` 기존 provider 키의 존재·사용 권한은 비밀값 없이 확인한다. 새 키 등록·인증/IAM 변경이 필요하면 해당 동작만 별도 승인받는다.

가격표·통화·원화 한도는 TEST_OPERATION 활성화 입력이 아니다. 실제 유료 검증 호출을 하려면 그 검증의 호출 범위를 따로 확정한다. 게시·V19 배포·설정 활성화 성공과 실제 공급자 품질 검증을 구분해 기록한다.

활성화 영향: 기존 UNCONFIGURED/HISTORICAL_UNKNOWN 방을 새 테스트 정책의 READY로 승격하지 않는다. 실제 검증은 기간 안에 새로 생성한 테스트 방으로 수행해야 한다. 기간 밖에서는 신규 AI 실행뿐 아니라 해당 정책의 새 방 초기화도 거부하므로, 서버 health/auth가 응답해도 새 방 생성이 성공한다는 뜻은 아니다. 만료 전 후속 운영 모드를 결정해야 하며 자동 정책 교체나 counter 초기화를 수행하지 않는다.
