-- Structural nonmonetary test scope. Reservation slots never refund when room-owned rows are deleted.
CREATE TABLE ai_test_operation_campaigns (
    id UUID PRIMARY KEY,
    policy_fingerprint VARCHAR(64) NOT NULL UNIQUE CHECK (policy_fingerprint ~ '^[0-9a-f]{64}$'),
    maximum_requests BIGINT NOT NULL CHECK (maximum_requests > 0),
    reserved_requests BIGINT NOT NULL DEFAULT 0,
    starts_epoch_seconds BIGINT NOT NULL,
    starts_nano INTEGER NOT NULL CHECK (starts_nano BETWEEN 0 AND 999999999),
    expires_epoch_seconds BIGINT NOT NULL,
    expires_nano INTEGER NOT NULL CHECK (expires_nano BETWEEN 0 AND 999999999),
    CHECK (reserved_requests >= 0 AND reserved_requests <= maximum_requests),
    CHECK ((expires_epoch_seconds, expires_nano) > (starts_epoch_seconds, starts_nano))
);

ALTER TABLE ai_room_budgets
    ADD COLUMN test_final_slots SMALLINT NOT NULL DEFAULT 0 CHECK (test_final_slots BETWEEN 0 AND 5);

ALTER TABLE ai_call_reservations
    ADD COLUMN test_campaign_id UUID REFERENCES ai_test_operation_campaigns(id);
