package com.meetme.server.shared.application.port.output

import java.time.Instant
import java.util.UUID

/** Nonmonetary, explicitly selected test scope. No field is a price or a known bill. */
data class AiTestOperationCampaign(
    val id: UUID,
    val policyFingerprint: String,
    val maximumRequests: Long,
    val startsAt: Instant,
    val expiresAt: Instant,
)

/** Called inside the existing budget transaction after room/execution/budget locks. */
interface AiTestOperationCampaignPort {
    fun reserve(
        campaign: AiTestOperationCampaign,
        additionalRequests: Long,
        deadlineAt: Instant,
    ): Boolean
}
