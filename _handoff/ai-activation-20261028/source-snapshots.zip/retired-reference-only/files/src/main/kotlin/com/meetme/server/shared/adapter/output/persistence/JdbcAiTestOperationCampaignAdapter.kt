package com.meetme.server.shared.adapter.output.persistence

import com.meetme.server.shared.application.port.output.AiTestOperationCampaign
import com.meetme.server.shared.application.port.output.AiTestOperationCampaignPort
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional
import java.time.Clock
import java.time.Instant

@Repository
class JdbcAiTestOperationCampaignAdapter(
    private val jdbc: JdbcTemplate,
    private val clock: Clock,
) : AiTestOperationCampaignPort {
    @Transactional(propagation = Propagation.MANDATORY)
    override fun reserve(
        campaign: AiTestOperationCampaign,
        additionalRequests: Long,
        deadlineAt: Instant,
    ): Boolean {
        if (!Regex("[0-9a-f]{64}").matches(campaign.policyFingerprint) ||
            campaign.maximumRequests <= 0 ||
            campaign.startsAt >= campaign.expiresAt ||
            additionalRequests < 0
        ) {
            return false
        }
        jdbc.update(
            """
            INSERT INTO ai_test_operation_campaigns
                (id,policy_fingerprint,maximum_requests,starts_epoch_seconds,starts_nano,expires_epoch_seconds,expires_nano)
            VALUES (?,?,?,?,?,?,?) ON CONFLICT DO NOTHING
            """.trimIndent(),
            campaign.id,
            campaign.policyFingerprint,
            campaign.maximumRequests,
            campaign.startsAt.epochSecond,
            campaign.startsAt.nano,
            campaign.expiresAt.epochSecond,
            campaign.expiresAt.nano,
        )
        val used =
            jdbc
                .query(
                    "SELECT * FROM ai_test_operation_campaigns WHERE id=? FOR UPDATE",
                    { rs, _ ->
                        if (rs.getString("policy_fingerprint") == campaign.policyFingerprint &&
                            rs.getLong("maximum_requests") == campaign.maximumRequests &&
                            rs.getLong("starts_epoch_seconds") == campaign.startsAt.epochSecond &&
                            rs.getInt("starts_nano") == campaign.startsAt.nano &&
                            rs.getLong("expires_epoch_seconds") == campaign.expiresAt.epochSecond &&
                            rs.getInt("expires_nano") == campaign.expiresAt.nano
                        ) {
                            rs.getLong("reserved_requests")
                        } else {
                            null
                        }
                    },
                    campaign.id,
                ).singleOrNull() ?: return false
        // Re-read after the row lock, including when INSERT waited on a competing transaction.
        val now = clock.instant()
        if (now < campaign.startsAt ||
            now >= campaign.expiresAt ||
            now >= deadlineAt ||
            used < 0 ||
            used > campaign.maximumRequests ||
            additionalRequests > campaign.maximumRequests - used
        ) {
            return false
        }
        if (additionalRequests == 0L) return true
        check(
            jdbc.update(
                "UPDATE ai_test_operation_campaigns SET reserved_requests=? WHERE id=? AND reserved_requests=?",
                used + additionalRequests,
                campaign.id,
                used,
            ) == 1,
        ) { "AI_TEST_OPERATION_COUNTER_CONFLICT" }
        return true
    }
}
